module.exports = {
  // Database configuration
  database: {
    filename: './femishield.db',
    timeout: 5000
  },
  
  // JWT configuration
  jwt: {
    secret: process.env.JWT_SECRET || 'femishield_secret_key_2024',
    expiresIn: '7d'
  },
  
  // Server configuration
  server: {
    port: process.env.PORT || 5000,
    corsOrigins: ['http://localhost:3000', 'http://127.0.0.1:5500']
  },
  
  // Assessment scoring thresholds
  assessments: {
    pcos: {
      low: 8,
      medium: 15
    },
    breast_cancer: {
      low: 5,
      medium: 10
    }
  }
};