class User {
  constructor(id, name, email, age, height, weight, createdAt) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.age = age;
    this.height = height;
    this.weight = weight;
    this.createdAt = createdAt;
  }

  calculateBMI() {
    if (!this.height || !this.weight) return null;
    return (this.weight / ((this.height / 100) ** 2)).toFixed(1);
  }
}

class Assessment {
  constructor(id, userId, assessmentType, score, riskLevel, bmi, details, createdAt) {
    this.id = id;
    this.userId = userId;
    this.assessmentType = assessmentType;
    this.score = score;
    this.riskLevel = riskLevel;
    this.bmi = bmi;
    this.details = details;
    this.createdAt = createdAt;
  }

  static getRiskLevel(score, type) {
    const thresholds = {
      pcos: { low: 8, medium: 15 },
      breast_cancer: { low: 5, medium: 10 }
    };

    const threshold = thresholds[type] || thresholds.pcos;

    if (score <= threshold.low) return 'Low';
    if (score <= threshold.medium) return 'Medium';
    return 'High';
  }
}

module.exports = { User, Assessment };