const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = 'femishield_secret_key_2024';

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Initialize SQLite Database
const db = new sqlite3.Database(':memory:');

// Create tables
db.serialize(() => {
  // Users table
  db.run(`CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    age INTEGER,
    height REAL,
    weight REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Assessment results table
  db.run(`CREATE TABLE assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    assessment_type TEXT NOT NULL,
    score INTEGER NOT NULL,
    risk_level TEXT NOT NULL,
    bmi REAL,
    details TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);

  // Insert demo user
  const hashedPassword = bcrypt.hashSync('password123', 10);
  db.run(`INSERT INTO users (name, email, password, age, height, weight) 
          VALUES (?, ?, ?, ?, ?, ?)`, 
          ['Sarah Johnson', 'sarah@example.com', hashedPassword, 28, 165, 62]);
});

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Routes

// User registration
app.post('/api/register', (req, res) => {
  const { name, email, password, age, height, weight } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);

  db.run(`INSERT INTO users (name, email, password, age, height, weight) 
          VALUES (?, ?, ?, ?, ?, ?)`, 
          [name, email, hashedPassword, age, height, weight], 
          function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(400).json({ error: 'Email already exists' });
      }
      return res.status(500).json({ error: 'Database error' });
    }

    const token = jwt.sign({ id: this.lastID, email }, JWT_SECRET);
    res.json({ 
      message: 'User registered successfully',
      token,
      user: { id: this.lastID, name, email, age, height, weight }
    });
  });
});

// User login
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user.id, email }, JWT_SECRET);
    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        age: user.age,
        height: user.height,
        weight: user.weight
      }
    });
  });
});

// Save assessment results
app.post('/api/assessments', authenticateToken, (req, res) => {
  const { assessment_type, score, risk_level, bmi, details } = req.body;
  const user_id = req.user.id;

  if (!assessment_type || score === undefined || !risk_level) {
    return res.status(400).json({ error: 'Assessment type, score, and risk level are required' });
  }

  db.run(`INSERT INTO assessments (user_id, assessment_type, score, risk_level, bmi, details) 
          VALUES (?, ?, ?, ?, ?, ?)`, 
          [user_id, assessment_type, score, risk_level, bmi, JSON.stringify(details)], 
          function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to save assessment' });
    }

    res.json({
      message: 'Assessment saved successfully',
      assessment_id: this.lastID
    });
  });
});

// Get user assessments
app.get('/api/assessments', authenticateToken, (req, res) => {
  const user_id = req.user.id;

  db.all(`SELECT * FROM assessments WHERE user_id = ? ORDER BY created_at DESC`, 
         [user_id], (err, assessments) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to fetch assessments' });
    }

    res.json({ assessments });
  });
});

// Get user profile
app.get('/api/profile', authenticateToken, (req, res) => {
  const user_id = req.user.id;

  db.get('SELECT id, name, email, age, height, weight, created_at FROM users WHERE id = ?', 
         [user_id], (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to fetch profile' });
    }

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  });
});

// Update user profile
app.put('/api/profile', authenticateToken, (req, res) => {
  const user_id = req.user.id;
  const { name, age, height, weight } = req.body;

  db.run(`UPDATE users SET name = ?, age = ?, height = ?, weight = ? WHERE id = ?`,
         [name, age, height, weight, user_id], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to update profile' });
    }

    res.json({ message: 'Profile updated successfully' });
  });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'FemiShield API is running',
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`FemiShield backend server running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
});

module.exports = app;