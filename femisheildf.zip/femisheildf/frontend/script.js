// API Base URL
const API_BASE_URL = 'http://localhost:5000/api';

// Global state
let currentUser = null;
let authToken = null;

// Page Navigation
function showPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.remove('active');
    });
    
    // Update active nav link
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('onclick') === `showPage('${pageId}')`) {
            link.classList.add('active');
        }
    });
    
    // Show the selected page
    document.getElementById(pageId).classList.add('active');
    
    // Scroll to top
    window.scrollTo(0, 0);
    
    // Load user data if going to dashboard
    if (pageId === 'dashboard' && currentUser) {
        loadUserAssessments();
    }
}

// Navbar scroll effect
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    checkAuthStatus();
    
    // Initialize assessment navigation
    initAssessmentNavigation();
    
    // Show demo credentials
    document.getElementById('demo-credentials').classList.remove('hidden');
});

// Authentication functions
function checkAuthStatus() {
    const savedToken = localStorage.getItem('femishield_token');
    const savedUser = localStorage.getItem('femishield_user');
    
    if (savedToken && savedUser) {
        authToken = savedToken;
        currentUser = JSON.parse(savedUser);
        updateUIForAuth();
    }
}

function updateUIForAuth() {
    const authLink = document.getElementById('auth-link');
    const userNameElement = document.getElementById('userName');
    const userAvatarIcon = document.getElementById('user-avatar-icon');
    const dashboardMessage = document.getElementById('dashboard-message');
    
    if (currentUser) {
        authLink.textContent = 'Logout';
        authLink.setAttribute('onclick', 'logout()');
        userNameElement.textContent = currentUser.name;
        userAvatarIcon.className = 'fas fa-user-check';
        dashboardMessage.textContent = `Welcome back! Continue your health journey with personalized assessments and tracking.`;
        
        // Pre-fill assessment forms with user data
        prefillAssessmentForms();
    } else {
        authLink.textContent = 'Login';
        authLink.setAttribute('onclick', 'showPage(\'login\')');
        userNameElement.textContent = 'Guest';
        userAvatarIcon.className = 'fas fa-user';
        dashboardMessage.textContent = 'Your health journey begins here. Ready to assess and understand your wellness better?';
    }
}

function prefillAssessmentForms() {
    if (currentUser) {
        // Pre-fill PCOS assessment
        document.getElementById('pcos-name').value = currentUser.name;
        document.getElementById('pcos-age').value = currentUser.age || '';
        document.getElementById('pcos-height').value = currentUser.height || '';
        document.getElementById('pcos-weight').value = currentUser.weight || '';
        
        // Pre-fill Breast Cancer assessment
        document.getElementById('name').value = currentUser.name;
        document.getElementById('age').value = currentUser.age || '';
        document.getElementById('height').value = currentUser.height || '';
        document.getElementById('weight').value = currentUser.weight || '';
    }
}

async function login() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    if (!email || !password) {
        alert('Please enter both email and password');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            
            // Save to localStorage
            localStorage.setItem('femishield_token', authToken);
            localStorage.setItem('femishield_user', JSON.stringify(currentUser));
            
            updateUIForAuth();
            showPage('dashboard');
            showNotification('Login successful!', 'success');
        } else {
            alert(data.error || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Login failed. Please try again.');
    }
}

async function register() {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const age = document.getElementById('register-age').value;
    const height = document.getElementById('register-height').value;
    const weight = document.getElementById('register-weight').value;
    
    if (!name || !email || !password) {
        alert('Please fill in all required fields');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                name, 
                email, 
                password, 
                age: parseInt(age) || null, 
                height: parseFloat(height) || null, 
                weight: parseFloat(weight) || null 
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            
            // Save to localStorage
            localStorage.setItem('femishield_token', authToken);
            localStorage.setItem('femishield_user', JSON.stringify(currentUser));
            
            updateUIForAuth();
            showPage('dashboard');
            showNotification('Registration successful!', 'success');
        } else {
            alert(data.error || 'Registration failed');
        }
    } catch (error) {
        console.error('Registration error:', error);
        alert('Registration failed. Please try again.');
    }
}

function logout() {
    authToken = null;
    currentUser = null;
    localStorage.removeItem('femishield_token');
    localStorage.removeItem('femishield_user');
    updateUIForAuth();
    showPage('home');
    showNotification('Logged out successfully', 'info');
}

function toggleAuthForm() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    if (loginForm.classList.contains('hidden')) {
        loginForm.classList.remove('hidden');
        registerForm.classList.add('hidden');
    } else {
        loginForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
    }
}

// Assessment Navigation
function initAssessmentNavigation() {
    // PCOS Assessment Submit
    const pcosSubmitBtn = document.getElementById('pcos-submit');
    pcosSubmitBtn.addEventListener('click', function() {
        generatePCOSReport();
    });
    
    // Breast Cancer Assessment Submit
    const breastSubmitBtn = document.getElementById('breast-submit');
    breastSubmitBtn.addEventListener('click', function() {
        generateReport();
    });
}

// Confetti Animation
function createConfetti() {
    const colors = ['#e75480', '#ff4081', '#9c27b0', '#ffb6c1'];
    for (let i = 0; i < 60; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = `${Math.random() * 100}vw`;
        confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.animationDelay = `${Math.random() * 5}s`;
        document.body.appendChild(confetti);
        
        setTimeout(() => {
            confetti.remove();
        }, 5000);
    }
}

// Calculate BMI
function calculateBMI(weight, height) {
    return (weight / ((height / 100) ** 2)).toFixed(1);
}

// Get selected radio value
function getSelectedValue(name) {
    const selected = document.querySelector(`input[name="${name}"]:checked`);
    return selected ? parseInt(selected.value) : 0;
}

// Check if all questions are answered
function checkAllQuestionsAnswered(prefix, totalQuestions) {
    for (let i = 1; i <= totalQuestions; i++) {
        if (!document.querySelector(`input[name="${prefix}${i}"]:checked`)) {
            return false;
        }
    }
    return true;
}

// Notification system
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    // Add styles if not already added
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 80px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 5px;
                color: white;
                z-index: 10000;
                display: flex;
                align-items: center;
                gap: 10px;
                max-width: 300px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                animation: slideInRight 0.3s ease;
            }
            .notification-success { background: #28a745; }
            .notification-error { background: #dc3545; }
            .notification-info { background: #17a2b8; }
            .notification-warning { background: #ffc107; color: #333; }
            .notification button {
                background: none;
                border: none;
                color: inherit;
                font-size: 18px;
                cursor: pointer;
                padding: 0;
                width: 20px;
                height: 20px;
            }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Load user assessments
async function loadUserAssessments() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/assessments`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayAssessments(data.assessments);
        }
    } catch (error) {
        console.error('Error loading assessments:', error);
    }
}

function displayAssessments(assessments) {
    const container = document.getElementById('assessments-list');
    
    if (!assessments || assessments.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: var(--text-light);">No assessments completed yet.</p>';
        return;
    }
    
    container.innerHTML = assessments.map(assessment => `
        <div class="assessment-history">
            <h4>${assessment.assessment_type.replace('_', ' ').toUpperCase()} Assessment</h4>
            <p><strong>Score:</strong> ${assessment.score} points</p>
            <p><strong>Risk Level:</strong> <span class="risk risk-${assessment.risk_level.toLowerCase()}">${assessment.risk_level}</span></p>
            <p><strong>Date:</strong> ${new Date(assessment.created_at).toLocaleDateString()}</p>
        </div>
    `).join('');
}

// Save assessment results
async function saveAssessmentResult(assessmentData) {
    if (!currentUser) return null;
    
    try {
        const response = await fetch(`${API_BASE_URL}/assessments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(assessmentData)
        });
        
        if (response.ok) {
            const data = await response.json();
            return data.assessment_id;
        }
    } catch (error) {
        console.error('Error saving assessment:', error);
    }
    
    return null;
}

// Breast Cancer Assessment
async function generateReport() {
    const name = document.getElementById("name").value.trim();
    const age = parseInt(document.getElementById("age").value);
    const height = parseFloat(document.getElementById("height").value);
    const weight = parseFloat(document.getElementById("weight").value);

    if (!name || !age || !height || !weight) {
        alert("Please fill in your personal details first!");
        return;
    }

    // Check if all questions are answered
    if (!checkAllQuestionsAnswered('q', 10)) {
        alert("Please answer all questions before submitting!");
        return;
    }

    const bmi = calculateBMI(weight, height);
    
    // Calculate actual score based on answers
    let score = 0;
    
    // Question 1: Age Group
    score += getSelectedValue('q1');
    
    // Question 2: First-degree relative with breast cancer
    score += getSelectedValue('q2');
    
    // Question 3: Second-degree relative with breast cancer
    score += getSelectedValue('q3');
    
    // Question 4: Benign breast lump or biopsy
    score += getSelectedValue('q4');
    
    // Question 5: Other cancers diagnosed
    score += getSelectedValue('q5');
    
    // Question 6: Menstruation before age 12
    score += getSelectedValue('q6');
    
    // Question 7: Menopause after age 55
    score += getSelectedValue('q7');
    
    // Question 8: Never had children
    score += getSelectedValue('q8');
    
    // Question 9: First child after age 30
    score += getSelectedValue('q9');
    
    // Question 10: Alcohol consumption
    score += getSelectedValue('q10');

    // Additional risk factors based on personal info
    if (age > 50) score += 2;
    if (bmi > 30) score += 1;
    if (bmi > 25) score += 1;

    // Determine risk level based on actual score
    let risk, riskClass, advice, alertMessage = "";

    if (score <= 5) {
        risk = "Low Risk 🌿";
        riskClass = "risk-low";
        advice = "Your breast cancer risk appears to be low. Maintain a healthy lifestyle with regular exercise, balanced diet, and routine self-exams. Continue with recommended screening guidelines for your age group.";
    } else if (score <= 10) {
        risk = "Moderate Risk 🌸";
        riskClass = "risk-medium";
        advice = "You have some risk factors for breast cancer. Be diligent with monthly self-exams and maintain regular clinical checkups. Consider discussing your risk factors with a healthcare provider for personalized screening recommendations.";
    } else {
        risk = "High Risk 💗";
        riskClass = "risk-high";
        advice = "Your assessment indicates several risk factors for breast cancer. It's important to consult with a healthcare professional for proper evaluation, personalized screening plan, and risk reduction strategies. Early detection is key.";
        alertMessage = `<div style="background:#ffcccc; color:#b30000; font-weight:bold; padding:8px; border-radius:5px; margin-bottom:10px; text-align:center;">
            ⚠️ High Risk Detected! Please consult a healthcare provider for proper evaluation and personalized screening recommendations.
        </div>`;
    }

    document.getElementById("breast-assessment").querySelector(".assessment-container").classList.add("hidden");

    const reportHTML = `
        <div style="text-align:right; font-size:11px; color:#555; margin-bottom:6px;">
            <i class="fas fa-phone"></i> 1234567890 | 0987654321 &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fas fa-envelope"></i> femishield@proj.com
        </div>

        ${alertMessage}

        <h2>Breast Cancer Risk Assessment Report</h2>
        <table border="1" cellpadding="5" cellspacing="0" style="margin:auto; margin-top:6px; border-collapse:collapse; width:98%; font-family:'Poppins', sans-serif;">
            <tr style="background:#ffe6f2; text-align:left;"><th>Field</th><th>Details</th></tr>
            <tr><td>Name</td><td>${name}</td></tr>
            <tr><td>Age</td><td>${age} years</td></tr>
            <tr><td>Height</td><td>${height} cm</td></tr>
            <tr><td>Weight</td><td>${weight} kg</td></tr>
            <tr><td>BMI</td><td>${bmi}</td></tr>
            <tr><td>Risk Score</td><td>${score} points</td></tr>
            <tr><td>Risk Level</td><td class="${riskClass}">${risk}</td></tr>
        </table>
        
        <div class="advice">
            <h3><i class="fas fa-lightbulb"></i> Recommendations</h3>
            <p>${advice}</p>
        </div>

        <h3>Lifestyle & Screening Tips</h3>
        <ul style="text-align:left; max-width:480px; margin:auto;">
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Perform regular breast self-exams monthly</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Maintain a healthy weight and balanced diet</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Exercise regularly (150+ minutes/week)</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Limit alcohol consumption</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Avoid smoking and secondhand smoke</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Follow age-appropriate screening guidelines</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Discuss family history with your doctor</li>
        </ul>
    `;

    document.getElementById("report").innerHTML = reportHTML;
    document.getElementById("resultContainer").classList.remove("hidden");
    
    // Save assessment result if user is logged in
    if (currentUser) {
        const assessmentData = {
            assessment_type: 'breast_cancer',
            score: score,
            risk_level: risk.replace(' 🌿', '').replace(' 🌸', '').replace(' 💗', ''),
            bmi: parseFloat(bmi),
            details: {
                age, height, weight, name,
                answers: {
                    q1: getSelectedValue('q1'),
                    q2: getSelectedValue('q2'),
                    q3: getSelectedValue('q3'),
                    q4: getSelectedValue('q4'),
                    q5: getSelectedValue('q5'),
                    q6: getSelectedValue('q6'),
                    q7: getSelectedValue('q7'),
                    q8: getSelectedValue('q8'),
                    q9: getSelectedValue('q9'),
                    q10: getSelectedValue('q10')
                }
            }
        };
        
        await saveAssessmentResult(assessmentData);
        loadUserAssessments(); // Refresh the assessments list
    }
    
    // Create confetti for completion
    createConfetti();
}

// PCOS Assessment
async function generatePCOSReport() {
    const name = document.getElementById("pcos-name").value.trim();
    const age = parseInt(document.getElementById("pcos-age").value);
    const height = parseFloat(document.getElementById("pcos-height").value);
    const weight = parseFloat(document.getElementById("pcos-weight").value);

    if (!name || !age || !height || !weight) {
        alert("Please fill in your personal details first!");
        return;
    }

    // Check if all questions are answered
    if (!checkAllQuestionsAnswered('q', 10)) {
        alert("Please answer all questions before submitting!");
        return;
    }

    const bmi = calculateBMI(weight, height);
    
    // Calculate actual score based on answers
    let score = 0;
    
    // Question 1: Menstrual cycle regularity
    score += getSelectedValue('q1');
    
    // Question 2: Unexplained weight gain
    score += getSelectedValue('q2');
    
    // Question 3: Excess facial/body hair
    score += getSelectedValue('q3');
    
    // Question 4: Acne or oily skin
    score += getSelectedValue('q4');
    
    // Question 5: Hair thinning on scalp
    score += getSelectedValue('q5');
    
    // Question 6: Skin darkening
    score += getSelectedValue('q6');
    
    // Question 7: Mood swings/anxiety/depression
    score += getSelectedValue('q7');
    
    // Question 8: Difficulty getting pregnant
    score += getSelectedValue('q8');
    
    // Question 9: Family history
    score += getSelectedValue('q9');
    
    // Question 10: Fatigue/low energy
    score += getSelectedValue('q10');

    // Additional risk factors based on personal info
    if (bmi > 30) score += 2;
    if (bmi > 25) score += 1;
    if (age < 35) score += 1; // PCOS often presents in younger women

    // Determine risk level based on actual score
    let risk, riskClass, advice, alertMessage = "";

    if (score <= 8) {
        risk = "Low Risk 🌿";
        riskClass = "risk-low";
        advice = "Your responses suggest a low likelihood of PCOS/PCOD. Continue maintaining a healthy lifestyle with balanced nutrition and regular physical activity. If you experience any changes in your symptoms, consult a healthcare provider.";
    } else if (score <= 15) {
        risk = "Moderate Risk 🌸";
        riskClass = "risk-medium";
        advice = "You may be experiencing some symptoms associated with PCOS/PCOD. Consider consulting a healthcare provider for proper evaluation. Focus on maintaining a healthy weight, balanced diet, and regular exercise to manage symptoms.";
    } else {
        risk = "High Risk 💗";
        riskClass = "risk-high";
        advice = "Your responses indicate a high likelihood of PCOS/PCOD. It's important to consult with a healthcare professional for proper diagnosis and treatment. Early intervention can help manage symptoms and prevent long-term complications.";
        alertMessage = `<div style="background:#ffcccc; color:#b30000; font-weight:bold; padding:8px; border-radius:5px; margin-bottom:10px; text-align:center;">
            ⚠️ High Risk Detected! Please consult a healthcare provider for proper evaluation and diagnosis of PCOS/PCOD.
        </div>`;
    }

    document.getElementById("pcos-assessment").querySelector(".assessment-container").classList.add("hidden");

    const reportHTML = `
        <div style="text-align:right; font-size:11px; color:#555; margin-bottom:6px;">
            <i class="fas fa-phone"></i> 1234567890 | 0987654321 &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fas fa-envelope"></i> femishield@proj.com
        </div>

        ${alertMessage}

        <h2>PCOS/PCOD Risk Assessment Report</h2>
        <table border="1" cellpadding="5" cellspacing="0" style="margin:auto; margin-top:6px; border-collapse:collapse; width:98%; font-family:'Poppins', sans-serif;">
            <tr style="background:#ffe6f2; text-align:left;"><th>Field</th><th>Details</th></tr>
            <tr><td>Name</td><td>${name}</td></tr>
            <tr><td>Age</td><td>${age} years</td></tr>
            <tr><td>Height</td><td>${height} cm</td></tr>
            <tr><td>Weight</td><td>${weight} kg</td></tr>
            <tr><td>BMI</td><td>${bmi}</td></tr>
            <tr><td>Symptom Score</td><td>${score} points</td></tr>
            <tr><td>Risk Level</td><td class="${riskClass}">${risk}</td></tr>
        </table>
        
        <div class="advice">
            <h3><i class="fas fa-lightbulb"></i> Recommendations</h3>
            <p>${advice}</p>
        </div>

        <h3>PCOS/PCOD Management Tips</h3>
        <ul style="text-align:left; max-width:480px; margin:auto;">
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Follow a balanced diet with low glycemic index foods</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Engage in regular physical activity (150+ minutes/week)</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Manage stress through meditation, yoga, or mindfulness</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Maintain healthy sleep habits (7-9 hours/night)</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Track menstrual cycles and symptoms</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Consider consulting a nutritionist or endocrinologist</li>
            <li><i class="fas fa-check-circle" style="color:var(--primary);"></i> Regular medical checkups for monitoring</li>
        </ul>
    `;

    document.getElementById("pcos-report").innerHTML = reportHTML;
    document.getElementById("pcos-result-container").classList.remove("hidden");
    
    // Save assessment result if user is logged in
    if (currentUser) {
        const assessmentData = {
            assessment_type: 'pcos',
            score: score,
            risk_level: risk.replace(' 🌿', '').replace(' 🌸', '').replace(' 💗', ''),
            bmi: parseFloat(bmi),
            details: {
                age, height, weight, name,
                answers: {
                    q1: getSelectedValue('q1'),
                    q2: getSelectedValue('q2'),
                    q3: getSelectedValue('q3'),
                    q4: getSelectedValue('q4'),
                    q5: getSelectedValue('q5'),
                    q6: getSelectedValue('q6'),
                    q7: getSelectedValue('q7'),
                    q8: getSelectedValue('q8'),
                    q9: getSelectedValue('q9'),
                    q10: getSelectedValue('q10')
                }
            }
        };
        
        await saveAssessmentResult(assessmentData);
        loadUserAssessments(); // Refresh the assessments list
    }
    
    // Create confetti for completion
    createConfetti();
}