// Chatbot Class - IMPROVED VERSION
class Chatbot {
    constructor() {
        this.chatWindow = document.getElementById('chatWindow');
        this.userInput = document.getElementById('userInput');
        this.sendButton = document.getElementById('sendButton');
        this.isProcessing = false;
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !this.isProcessing) {
                this.sendMessage();
            }
        });

        // Enable/disable input based on processing state
        this.userInput.addEventListener('input', () => {
            this.sendButton.disabled = this.userInput.value.trim() === '' || this.isProcessing;
        });
    }

    async sendMessage() {
        if (this.isProcessing) return;
        
        const message = this.userInput.value.trim();
        if (!message) return;
        
        // Add user message
        this.addMessage(message, true);
        this.userInput.value = '';
        this.sendButton.disabled = true;
        this.isProcessing = true;
        
        // Show typing indicator
        const typingIndicator = this.showTypingIndicator();
        
        try {
            console.log('📤 Sending message to backend:', message);
            const response = await fetch(`${API_BASE_URL}/chat`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ message })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('📥 Received response:', data);
            
            this.removeTypingIndicator(typingIndicator);
            this.addMessage(data.response, false);
            
        } catch (error) {
            console.error('❌ Chat error:', error);
            this.removeTypingIndicator(typingIndicator);
            
            // Fallback responses when backend is unavailable
            const fallbackResponse = this.getFallbackResponse(message);
            this.addMessage(fallbackResponse, false);
        } finally {
            this.isProcessing = false;
            this.sendButton.disabled = false;
            this.userInput.focus();
        }
    }

    getFallbackResponse(message) {
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
            return "Hello! I'm HopeWell Assistant. I'm currently experiencing some connection issues, but I'm here to help with cancer-related questions and support.";
        }
        else if (lowerMessage.includes('symptom') || lowerMessage.includes('pain')) {
            return "I understand you're asking about symptoms. While I'm having connection issues, I recommend discussing any persistent symptoms with your healthcare provider for proper evaluation.";
        }
        else if (lowerMessage.includes('treatment')) {
            return "Treatment options vary based on cancer type and stage. Common approaches include surgery, chemotherapy, radiation, and targeted therapies. Please consult with your oncology team for personalized information.";
        }
        else {
            return "Thank you for your message. I'm currently experiencing connection issues, but I'm here to provide cancer information and support. You can also try our risk assessment tool or join our community chat for additional support.";
        }
    }

    addMessage(text, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
        
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        bubble.textContent = text;
        
        messageDiv.appendChild(bubble);
        this.chatWindow.appendChild(messageDiv);
        this.chatWindow.scrollTop = this.chatWindow.scrollHeight;
    }

    showTypingIndicator() {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot-message';
        messageDiv.id = 'typing-indicator';
        
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        bubble.innerHTML = '<div class="typing-indicator"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>';
        
        messageDiv.appendChild(bubble);
        this.chatWindow.appendChild(messageDiv);
        this.chatWindow.scrollTop = this.chatWindow.scrollHeight;
        
        return messageDiv;
    }

    removeTypingIndicator() {
        const indicator = document.getElementById('typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }
}