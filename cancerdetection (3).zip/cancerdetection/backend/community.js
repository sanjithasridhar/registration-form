const express = require('express');
const router = express.Router();

// Sample community data
let communityData = {
  users: [
    {
      id: 1,
      name: "Sarah_M",
      role: "survivor",
      cancerType: "Breast Cancer",
      joinDate: "2023-01-15",
      avatar: "SM",
      isOnline: true
    },
    {
      id: 2,
      name: "John_D",
      role: "caregiver",
      cancerType: "",
      joinDate: "2023-02-20",
      avatar: "JD",
      isOnline: true
    },
    {
      id: 3,
      name: "Maria_T",
      role: "patient",
      cancerType: "Lung Cancer",
      joinDate: "2023-03-10",
      avatar: "MT",
      isOnline: true
    }
  ],
  
  supportGroups: [
    {
      id: 1,
      name: "Breast Cancer Support",
      description: "For those affected by breast cancer",
      memberCount: 342,
      isPrivate: false
    },
    {
      id: 2,
      name: "Lung Cancer Community",
      description: "Support for lung cancer patients and families",
      memberCount: 189,
      isPrivate: false
    },
    {
      id: 3,
      name: "Caregivers Network",
      description: "Support for those caring for cancer patients",
      memberCount: 276,
      isPrivate: false
    }
  ],
  
  events: [
    {
      id: 1,
      title: "Virtual Support Group Meeting",
      date: "2023-12-15",
      time: "19:00",
      type: "virtual",
      description: "Monthly virtual support group for cancer patients and survivors"
    },
    {
      id: 2,
      title: "Nutrition Workshop",
      date: "2024-01-10",
      time: "14:00",
      type: "virtual",
      description: "Learn about nutrition during cancer treatment"
    }
  ]
};

// Get community statistics
router.get('/stats', (req, res) => {
  res.json({
    totalMembers: 2847,
    onlineNow: 156,
    supportGroups: 42,
    resourcesShared: 1256
  });
});

// Get online users
router.get('/users/online', (req, res) => {
  const onlineUsers = communityData.users.filter(user => user.isOnline);
  res.json(onlineUsers);
});

// Get support groups
router.get('/groups', (req, res) => {
  res.json(communityData.supportGroups);
});

// Get events
router.get('/events', (req, res) => {
  res.json(communityData.events);
});

// Join support group
router.post('/groups/:id/join', (req, res) => {
  const groupId = parseInt(req.params.id);
  const group = communityData.supportGroups.find(g => g.id === groupId);
  
  if (group) {
    group.memberCount += 1;
    res.json({ success: true, message: "Successfully joined group" });
  } else {
    res.status(404).json({ success: false, message: "Group not found" });
  }
});

// Create new support group
router.post('/groups', (req, res) => {
  const { name, description, isPrivate } = req.body;
  
  const newGroup = {
    id: communityData.supportGroups.length + 1,
    name,
    description,
    memberCount: 1,
    isPrivate: isPrivate || false
  };
  
  communityData.supportGroups.push(newGroup);
  res.json({ success: true, group: newGroup });
});

module.exports = router;