const { NlpManager } = require('node-nlp');

class CancerSupportChatbot {
    constructor() {
        this.manager = new NlpManager({ languages: ['en'] });
        this.setupNLP();
    }

    setupNLP() {
        // Add documents and responses for cancer support
        this.addDocuments();
        this.addAnswers();
        
        // Train the model
        this.manager.train();
    }

    addDocuments() {
        // Greetings
        this.manager.addDocument('en', 'hello', 'greeting');
        this.manager.addDocument('en', 'hi', 'greeting');
        this.manager.addDocument('en', 'hey', 'greeting');
        this.manager.addDocument('en', 'good morning', 'greeting');
        this.manager.addDocument('en', 'good afternoon', 'greeting');

        // Symptoms
        this.manager.addDocument('en', 'I have pain', 'symptoms');
        this.manager.addDocument('en', 'I feel pain', 'symptoms');
        this.manager.addDocument('en', 'I have symptoms', 'symptoms');
        this.manager.addDocument('en', 'I am experiencing symptoms', 'symptoms');
        this.manager.addDocument('en', 'I have a lump', 'symptoms');
        this.manager.addDocument('en', 'I found a lump', 'symptoms');
        this.manager.addDocument('en', 'I have fatigue', 'symptoms');
        this.manager.addDocument('en', 'I feel tired', 'symptoms');
        this.manager.addDocument('en', 'I have weight loss', 'symptoms');
        this.manager.addDocument('en', 'I lost weight', 'symptoms');

        // Support
        this.manager.addDocument('en', 'I need support', 'support');
        this.manager.addDocument('en', 'I am scared', 'support');
        this.manager.addDocument('en', 'I am afraid', 'support');
        this.manager.addDocument('en', 'I am worried', 'support');
        this.manager.addDocument('en', 'I need help', 'support');
        this.manager.addDocument('en', 'I feel anxious', 'support');
        this.manager.addDocument('en', 'I feel depressed', 'support');

        // Treatment
        this.manager.addDocument('en', 'chemotherapy', 'treatment');
        this.manager.addDocument('en', 'radiation', 'treatment');
        this.manager.addDocument('en', 'surgery', 'treatment');
        this.manager.addDocument('en', 'treatment options', 'treatment');
        this.manager.addDocument('en', 'side effects', 'treatment');

        // Cancer types
        this.manager.addDocument('en', 'breast cancer', 'cancer.breast');
        this.manager.addDocument('en', 'lung cancer', 'cancer.lung');
        this.manager.addDocument('en', 'prostate cancer', 'cancer.prostate');
        this.manager.addDocument('en', 'colon cancer', 'cancer.colon');
        this.manager.addDocument('en', 'skin cancer', 'cancer.skin');
        this.manager.addDocument('en', 'leukemia', 'cancer.leukemia');
        this.manager.addDocument('en', 'lymphoma', 'cancer.lymphoma');

        // Resources
        this.manager.addDocument('en', 'resources', 'resources');
        this.manager.addDocument('en', 'support groups', 'resources');
        this.manager.addDocument('en', 'helpful links', 'resources');
        this.manager.addDocument('en', 'information', 'resources');

        // Goodbye
        this.manager.addDocument('en', 'bye', 'goodbye');
        this.manager.addDocument('en', 'goodbye', 'goodbye');
        this.manager.addDocument('en', 'see you', 'goodbye');
        this.manager.addDocument('en', 'talk later', 'goodbye');
    }

    addAnswers() {
        // Greeting responses
        this.manager.addAnswer('en', 'greeting', 'Hello! I\'m HopeWell Assistant. I\'m here to provide information and support about cancer. How can I help you today?');
        this.manager.addAnswer('en', 'greeting', 'Welcome! I can help you understand symptoms, treatment options, and connect you with support resources. What would you like to know?');
        this.manager.addAnswer('en', 'greeting', 'Hi there! I\'m here to listen and provide cancer-related information. Remember, I\'m not a doctor, but I can offer guidance and support.');

        // Symptom responses
        this.manager.addAnswer('en', 'symptoms', 'I understand you\'re concerned about symptoms. It\'s important to discuss any persistent changes with a healthcare provider. Can you tell me more about what you\'re experiencing?');
        this.manager.addAnswer('en', 'symptoms', 'Thank you for sharing. Remember, many symptoms have benign causes, but it\'s always wise to get persistent changes checked by a doctor. How long have you been experiencing these symptoms?');
        this.manager.addAnswer('en', 'symptoms', 'I hear your concern about symptoms. While I can\'t provide medical advice, I can help you understand when it might be appropriate to seek medical attention.');

        // Support responses
        this.manager.addAnswer('en', 'support', 'It\'s completely normal to feel worried or anxious. Many people find comfort in talking to loved ones or joining support groups. Would you like information about support resources?');
        this.manager.addAnswer('en', 'support', 'I hear you. Dealing with health concerns can be incredibly stressful. Remember to practice self-care and reach out to healthcare professionals who can provide proper guidance.');
        this.manager.addAnswer('en', 'support', 'Your feelings are completely valid. Many in our community have felt the same way. Would you like to connect with others who understand what you\'re going through?');

        // Treatment responses
        this.manager.addAnswer('en', 'treatment', 'Treatment options vary depending on the type and stage of cancer. Common approaches include surgery, chemotherapy, radiation, and targeted therapies. It\'s best to discuss specific options with your oncology team.');
        this.manager.addAnswer('en', 'treatment', 'Managing treatment side effects is an important part of cancer care. Your medical team can provide medications and strategies to help with symptoms like nausea, fatigue, or pain.');

        // Cancer type specific responses
        this.manager.addAnswer('en', 'cancer.breast', 'Breast cancer is the most common cancer in women. Early detection through mammograms and self-exams is crucial. Treatment often involves surgery, radiation, chemotherapy, or hormone therapy.');
        this.manager.addAnswer('en', 'cancer.lung', 'Lung cancer is often linked to smoking but can occur in non-smokers too. Symptoms may include persistent cough, chest pain, or shortness of breath. Treatment depends on the type and stage.');
        this.manager.addAnswer('en', 'cancer.prostate', 'Prostate cancer is common in men, especially as they age. Screening typically involves PSA blood tests and digital exams. Many prostate cancers grow slowly and may not require immediate treatment.');

        // Resource responses
        this.manager.addAnswer('en', 'resources', 'Here are some helpful resources:\n- American Cancer Society: cancer.org\n- National Cancer Institute: cancer.gov\n- Cancer Support Community: cancersupportcommunity.org\n- Our live community chat for peer support');
        this.manager.addAnswer('en', 'resources', 'I recommend checking these organizations for reliable information:\n- CancerCare for counseling and support: cancercare.org\n- Susan G. Komen for breast cancer: komen.org\n- Leukemia & Lymphoma Society: lls.org');

        // Goodbye responses
        this.manager.addAnswer('en', 'goodbye', 'Take care! Remember, you\'re not alone in this journey. Reach out anytime you need support.');
        this.manager.addAnswer('en', 'goodbye', 'Goodbye! I\'m always here if you need to talk. Wishing you strength and comfort.');
        this.manager.addAnswer('en', 'goodbye', 'See you later! Don\'t hesitate to return if you have more questions or just need someone to listen.');
    }

    async processMessage(message, conversation) {
        try {
            const response = await this.manager.process('en', message);
            
            if (response.answer) {
                return response.answer;
            }

            // Fallback responses based on conversation context
            const lastMessage = conversation[conversation.length - 2];
            if (lastMessage && lastMessage.role === 'user') {
                return this.getContextualResponse(lastMessage.content, message);
            }

            // Default response
            return "Thank you for sharing. I'm here to provide supportive information about cancer awareness and resources. If you have specific concerns about symptoms, it's always best to consult with a healthcare professional who can evaluate your individual situation.";
            
        } catch (error) {
            console.error('NLP processing error:', error);
            return "I'm here to listen and provide support. Could you tell me more about what's on your mind?";
        }
    }

    getContextualResponse(previousMessage, currentMessage) {
        const prevLower = previousMessage.toLowerCase();
        const currLower = currentMessage.toLowerCase();

        if (prevLower.includes('symptom') || currLower.includes('symptom')) {
            return "I understand you're discussing symptoms. It's important to track any persistent changes and share them with your doctor. They can help determine if further evaluation is needed.";
        }

        if (prevLower.includes('treatment') || currLower.includes('treatment')) {
            return "Treatment decisions are personal and should be made with your healthcare team. They consider the cancer type, stage, your overall health, and personal preferences when recommending options.";
        }

        if (prevLower.includes('scared') || currLower.includes('scared') || 
            prevLower.includes('afraid') || currLower.includes('afraid')) {
            return "It's completely normal to feel fearful when dealing with cancer concerns. Many find it helpful to connect with others who've been through similar experiences. Would you like me to tell you about our support community?";
        }

        return "Thank you for sharing. I'm listening and here to support you. Is there anything specific you'd like to know more about?";
    }
}

module.exports = new CancerSupportChatbot();