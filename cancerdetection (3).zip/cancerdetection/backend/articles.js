const express = require('express');
const router = express.Router();

// Articles database
const articles = {
    awareness: [
        {
            id: 1,
            title: "Understanding Early Detection",
            content: "Early detection of cancer can significantly improve treatment outcomes. Regular screenings like mammograms, colonoscopies, and skin checks can identify cancer in its earliest stages when it's most treatable.",
            category: "prevention",
            readTime: "3 min"
        },
        {
            id: 2,
            title: "Common Cancer Symptoms to Watch For",
            content: "While symptoms vary by cancer type, some general signs include persistent fatigue, unexplained weight loss, persistent pain, skin changes, and changes in bowel or bladder habits. Always consult a doctor for proper evaluation.",
            category: "symptoms",
            readTime: "4 min"
        }
    ],
    
    prevention: [
        {
            id: 3,
            title: "Lifestyle Choices for Cancer Prevention",
            content: "Maintaining a healthy weight, eating a balanced diet rich in fruits and vegetables, limiting alcohol, avoiding tobacco, and protecting yourself from the sun can reduce cancer risks.",
            category: "prevention",
            readTime: "5 min"
        },
        {
            id: 4,
            title: "The Importance of Regular Exercise",
            content: "Regular physical activity can help reduce the risk of several cancer types. Aim for at least 150 minutes of moderate exercise or 75 minutes of vigorous exercise weekly.",
            category: "prevention",
            readTime: "3 min"
        }
    ],
    
    support: [
        {
            id: 5,
            title: "Coping with Health Anxiety",
            content: "It's normal to feel anxious about health concerns. Practice mindfulness, maintain social connections, and seek professional support if anxiety becomes overwhelming.",
            category: "emotional",
            readTime: "4 min"
        },
        {
            id: 6,
            title: "Building a Support Network",
            content: "Connecting with others who understand your concerns can provide comfort and practical advice. Consider joining support groups or talking with trusted friends and family.",
            category: "emotional", 
            readTime: "3 min"
        }
    ]
};

// Get all articles by category
router.get('/:category', (req, res) => {
    const category = req.params.category;
    const categoryArticles = articles[category] || [];
    
    res.json({
        category,
        articles: categoryArticles,
        count: categoryArticles.length
    });
});

// Get specific article
router.get('/article/:id', (req, res) => {
    const id = parseInt(req.params.id);
    
    // Search through all categories for the article
    let foundArticle = null;
    Object.keys(articles).forEach(category => {
        const article = articles[category].find(a => a.id === id);
        if (article) {
            foundArticle = article;
        }
    });
    
    if (foundArticle) {
        res.json(foundArticle);
    } else {
        res.status(404).json({ error: 'Article not found' });
    }
});

// Get all articles
router.get('/', (req, res) => {
    res.json(articles);
});

module.exports = router;