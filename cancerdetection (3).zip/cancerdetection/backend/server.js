const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Enhanced chatbot with better response logic
class Chatbot {
    constructor() {
        this.responses = {
            greeting: [
                "Hello! I'm HopeWell Assistant. I'm here to provide information and support about cancer. How can I help you today?",
                "Welcome! I can help you understand symptoms, treatment options, and connect you with support resources. What would you like to know?",
                "Hi there! I'm here to listen and provide cancer-related information. Remember, I'm not a doctor, but I can offer guidance and support."
            ],
            symptoms: [
                "I understand you're concerned about symptoms. It's important to discuss any persistent changes with a healthcare provider. Common symptoms to watch for include unexplained weight loss, persistent fatigue, lumps, or changes in bowel habits.",
                "Thank you for sharing your symptoms. While I can't diagnose, I can help you understand when to seek medical attention. Symptoms that persist for more than 2 weeks should typically be evaluated by a doctor.",
                "I hear your concern about symptoms. Many symptoms have benign causes, but it's always wise to get persistent changes checked. Would you like me to help you understand which symptoms might need urgent attention?"
            ],
            pain: [
                "I'm sorry to hear you're experiencing pain. Pain management is an important part of cancer care. Your healthcare team can help with pain control strategies and medications.",
                "Pain can be concerning. It's important to track your pain - note its location, intensity, and what makes it better or worse. Share this information with your doctor.",
                "Persistent pain should always be discussed with your healthcare provider. They can help determine the cause and provide appropriate treatment options."
            ],
            diagnosis: [
                "A cancer diagnosis can feel overwhelming. Remember that many cancers are treatable, and new treatments are being developed all the time. It's important to work with a healthcare team you trust.",
                "Receiving a diagnosis is challenging. Many find it helpful to bring a family member or friend to appointments to help remember information and ask questions.",
                "After a diagnosis, it's normal to have many questions. Write them down as they come to you so you can discuss them with your healthcare team."
            ],
            treatment: [
                "Treatment options depend on the cancer type, stage, and your overall health. Common approaches include surgery, chemotherapy, radiation, immunotherapy, and targeted therapy.",
                "Cancer treatment has advanced significantly. Your oncology team will recommend a treatment plan based on the latest evidence and your individual situation.",
                "Managing treatment side effects is crucial. Don't hesitate to ask your healthcare team about medications and strategies to help with symptoms like nausea, fatigue, or pain."
            ],
            support: [
                "It's completely normal to feel worried or anxious. Many people find comfort in talking to loved ones or joining support groups. Would you like information about support resources?",
                "Dealing with cancer concerns can be incredibly stressful. Remember to practice self-care and reach out to healthcare professionals who can provide proper guidance.",
                "Your feelings are completely valid. Many in our community have felt the same way. Our live support community is available 24/7 for connection and support."
            ],
            prevention: [
                "Cancer prevention strategies include maintaining a healthy weight, eating a balanced diet rich in fruits and vegetables, regular exercise, avoiding tobacco, limiting alcohol, and protecting your skin from the sun.",
                "Regular screenings can help detect some cancers early when they're most treatable. Talk to your doctor about which screenings are appropriate for your age and risk factors.",
                "Knowing your family health history can help you and your doctor understand your cancer risk and determine appropriate prevention strategies."
            ],
            resources: [
                "Here are some reliable cancer resources:\n- American Cancer Society: cancer.org\n- National Cancer Institute: cancer.gov\n- Cancer Support Community: cancersupportcommunity.org",
                "I recommend these organizations for support and information:\n- CancerCare for counseling: cancercare.org\n- Leukemia & Lymphoma Society: lls.org\n- Our live community chat for peer support",
                "For reliable information, check:\n- Clinical trials: clinicaltrials.gov\n- Cancer research updates: cancerresearch.org\n- Patient support: cancer.net"
            ],
            goodbye: [
                "Take care! Remember, you're not alone in this journey. Reach out anytime you need support.",
                "Goodbye! I'm always here if you need to talk. Wishing you strength and comfort.",
                "See you later! Don't hesitate to return if you have more questions or just need someone to listen."
            ],
            default: [
                "Thank you for sharing. I'm here to provide supportive information about cancer awareness and resources. If you have specific concerns about symptoms, it's always best to consult with a healthcare professional.",
                "I understand you're looking for information. Our community might have insights from personal experiences. Would you like me to connect you with our support community?",
                "Thank you for your message. I'm listening and here to support you. Could you tell me more about what's on your mind?"
            ]
        };
    }

    processMessage(message) {
        const lowerMessage = message.toLowerCase().trim();
        
        // Greeting detection
        if (/(hello|hi|hey|good morning|good afternoon)/i.test(lowerMessage)) {
            return this.getRandomResponse('greeting');
        }
        
        // Symptom detection
        if (/(symptom|pain|hurt|ache|uncomfortable|discomfort)/i.test(lowerMessage)) {
            if (/(pain|hurt|ache)/i.test(lowerMessage)) {
                return this.getRandomResponse('pain');
            }
            return this.getRandomResponse('symptoms');
        }
        
        // Diagnosis related
        if (/(diagnos|result|positive|malignant|biopsy)/i.test(lowerMessage)) {
            return this.getRandomResponse('diagnosis');
        }
        
        // Treatment related
        if (/(treatment|chemo|radiation|therapy|medication|drug)/i.test(lowerMessage)) {
            return this.getRandomResponse('treatment');
        }
        
        // Emotional support
        if (/(scared|afraid|worried|anxious|nervous|stress|depress|overwhelm)/i.test(lowerMessage)) {
            return this.getRandomResponse('support');
        }
        
        // Prevention
        if (/(prevent|risk|avoid|lower|reduce)/i.test(lowerMessage)) {
            return this.getRandomResponse('prevention');
        }
        
        // Resources
        if (/(resource|help|information|website|organization|support group)/i.test(lowerMessage)) {
            return this.getRandomResponse('resources');
        }
        
        // Goodbye
        if (/(bye|goodbye|see you|talk later|farewell)/i.test(lowerMessage)) {
            return this.getRandomResponse('goodbye');
        }
        
        // Cancer type specific
        const cancerTypes = [
            'breast', 'lung', 'prostate', 'colon', 'skin', 'leukemia', 'lymphoma', 
            'carcinoma', 'sarcoma', 'melanoma', 'myeloma', 'glioma', 'blastoma'
        ];
        
        for (const type of cancerTypes) {
            if (lowerMessage.includes(type)) {
                return this.getCancerSpecificResponse(type);
            }
        }
        
        return this.getRandomResponse('default');
    }

    getRandomResponse(type) {
        const responses = this.responses[type];
        return responses[Math.floor(Math.random() * responses.length)];
    }

    getCancerSpecificResponse(cancerType) {
        const cancerInfo = {
            'breast': "Breast cancer is the most common cancer in women. Early detection through mammograms and self-exams is crucial. Treatment often involves surgery, radiation, chemotherapy, or hormone therapy.",
            'lung': "Lung cancer is often linked to smoking but can occur in non-smokers too. Symptoms may include persistent cough, chest pain, or shortness of breath. Treatment depends on the type and stage.",
            'prostate': "Prostate cancer is common in men, especially as they age. Screening typically involves PSA blood tests. Many prostate cancers grow slowly and may not require immediate treatment.",
            'colon': "Colon cancer often develops from polyps in the colon. Regular colonoscopies can detect and remove polyps before they become cancerous. Symptoms may include changes in bowel habits or blood in stool.",
            'leukemia': "Leukemia is cancer of blood-forming tissues. Symptoms can include fatigue, frequent infections, and easy bruising. Treatment depends on the type and may include chemotherapy, radiation, or stem cell transplant.",
            'lymphoma': "Lymphoma affects the lymphatic system. There are two main types: Hodgkin and non-Hodgkin lymphoma. Treatment often involves chemotherapy, radiation, or immunotherapy."
        };
        
        return cancerInfo[cancerType] || `I understand you're asking about ${cancerType} cancer. This type affects specific cells in the body, and treatment options vary based on the specific subtype and stage. It's best to discuss this with your oncology team for personalized information.`;
    }
}

const chatbot = new Chatbot();

// Calculate risk assessment
function calculateRiskAssessment(answers, cancerType = null) {
    let totalScore = 0;
    const maxScore = 6 * 3;
    
    for (let i = 1; i <= 6; i++) {
        totalScore += answers[i] || 0;
    }
    
    const percentage = (totalScore / maxScore) * 100;
    
    let riskLevel, recommendations;
    
    if (percentage < 30) {
        riskLevel = 'low';
        recommendations = [
            "Continue with regular health check-ups and age-appropriate cancer screenings",
            "Maintain your healthy lifestyle habits including balanced diet and regular exercise",
            "Stay informed about new cancer prevention research and recommendations",
            "Consider genetic counseling if you have specific concerns about family history"
        ];
    } else if (percentage < 60) {
        riskLevel = 'moderate';
        recommendations = [
            "Schedule a consultation with your healthcare provider to discuss your risk factors",
            "Consider more frequent cancer screenings based on your specific risk profile",
            "Focus on modifiable risk factors like improving diet, increasing exercise, and smoking cessation",
            "Discuss family history with a genetic counselor if applicable"
        ];
    } else {
        riskLevel = 'high';
        recommendations = [
            "Schedule an appointment with a healthcare provider as soon as possible for comprehensive evaluation",
            "Discuss appropriate screening schedules and preventive measures with your doctor",
            "Consider genetic testing and counseling based on your family history and risk factors",
            "Work with professionals to address modifiable risk factors",
            "Join our support community to connect with others managing similar risks"
        ];
    }

    return {
        riskLevel,
        score: totalScore,
        maxScore,
        percentage: Math.round(percentage),
        recommendations,
        cancerType: cancerType || 'Not specified'
    };
}

// Routes

// Serve frontend
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Chat endpoint - FIXED with better processing
app.post('/api/chat', (req, res) => {
    try {
        console.log('📨 Received chat message:', req.body.message);
        const { message } = req.body;
        
        if (!message || message.trim() === '') {
            return res.status(400).json({ error: 'Message is required' });
        }

        const response = chatbot.processMessage(message);
        console.log('🤖 Sending response:', response);
        
        res.json({
            response,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('❌ Chat error:', error);
        res.status(500).json({ 
            response: "I'm having some technical difficulties right now. Please try again in a moment, or feel free to browse our resources and community support in the meantime."
        });
    }
});

// Assessment endpoint
app.post('/api/assessment', (req, res) => {
    try {
        console.log('📊 Assessment submission received');
        const { answers, cancerType } = req.body;
        
        if (!answers) {
            return res.status(400).json({ error: 'Assessment answers are required' });
        }

        const result = calculateRiskAssessment(answers, cancerType);
        console.log('📈 Assessment result:', result.riskLevel);
        
        res.json(result);
    } catch (error) {
        console.error('❌ Assessment error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get cancer types
app.get('/api/cancer-types', (req, res) => {
    const cancerTypes = [
        { name: "Carcinoma", location: "Organs" },
        { name: "Sarcoma", location: "Tissue" },
        { name: "Leukemia", location: "Blood" },
        { name: "Lymphoma", location: "Immunity" },
        { name: "Melanoma", location: "Skin" },
        { name: "Myeloma", location: "Marrow" },
        { name: "Glioma", location: "Brain" },
        { name: "Blastoma", location: "Embryonic" },
        { name: "Germinoma", location: "Reproductive" },
        { name: "Meningioma", location: "Meninges" }
    ];
    
    res.json(cancerTypes);
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        message: 'HopeWell Backend is running successfully!',
        services: {
            chat: 'operational',
            assessment: 'operational',
            community: 'operational'
        }
    });
});

// Test endpoint
app.get('/api/test', (req, res) => {
    res.json({ 
        message: 'Backend is connected and working!',
        timestamp: new Date().toISOString(),
        chatbot: 'Ready to assist with cancer-related questions'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`=================================`);
    console.log(`🚀 HopeWell Server is RUNNING!`);
    console.log(`📍 Port: ${PORT}`);
    console.log(`🌐 Frontend: http://localhost:${PORT}`);
    console.log(`🤖 Chatbot: Ready with enhanced responses`);
    console.log(`✅ Health: http://localhost:${PORT}/api/health`);
    console.log(`=================================`);
});