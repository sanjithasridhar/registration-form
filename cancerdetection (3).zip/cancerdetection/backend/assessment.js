class RiskAssessment {
    calculateRisk(answers, cancerType = null) {
        let totalScore = 0;
        const maxScore = 6 * 3; // 6 questions, max 3 points each
        
        // Calculate total score from answers
        for (let i = 1; i <= 6; i++) {
            totalScore += answers[i] || 0;
        }
        
        const percentage = (totalScore / maxScore) * 100;
        
        let riskLevel, recommendations, cancerSpecificInfo = null;
        
        if (percentage < 30) {
            riskLevel = 'low';
            recommendations = this.getLowRiskRecommendations();
        } else if (percentage < 60) {
            riskLevel = 'moderate';
            recommendations = this.getModerateRiskRecommendations();
        } else {
            riskLevel = 'high';
            recommendations = this.getHighRiskRecommendations();
        }

        // Add cancer-specific information if provided
        if (cancerType) {
            cancerSpecificInfo = this.getCancerSpecificInfo(cancerType);
        }

        return {
            riskLevel,
            score: totalScore,
            maxScore,
            percentage: Math.round(percentage),
            recommendations,
            cancerSpecificInfo
        };
    }

    getLowRiskRecommendations() {
        return [
            "Continue with regular health check-ups and age-appropriate cancer screenings",
            "Maintain your healthy lifestyle habits including balanced diet and regular exercise",
            "Stay informed about new cancer prevention research and recommendations",
            "Consider genetic counseling if you have specific concerns about family history",
            "Practice sun safety and avoid tobacco products to maintain low risk",
            "Stay up to date with vaccinations that can prevent cancer-causing infections"
        ];
    }

    getModerateRiskRecommendations() {
        return [
            "Schedule a consultation with your healthcare provider to discuss your risk factors",
            "Consider more frequent cancer screenings based on your specific risk profile",
            "Focus on modifiable risk factors like improving diet, increasing exercise, and smoking cessation if applicable",
            "Discuss family history with a genetic counselor to understand inherited risks",
            "Limit alcohol consumption and maintain a healthy body weight",
            "Consider joining a cancer prevention program or support group"
        ];
    }

    getHighRiskRecommendations() {
        return [
            "Schedule an appointment with a healthcare provider as soon as possible for comprehensive evaluation",
            "Discuss appropriate screening schedules and preventive measures with your doctor",
            "Consider genetic testing and counseling based on your family history and risk factors",
            "Work with healthcare professionals to develop a personalized risk reduction plan",
            "Join our support community to connect with others managing similar risks",
            "Explore clinical trials or prevention studies that might be appropriate for your situation",
            "Make significant lifestyle changes focusing on nutrition, physical activity, and avoiding carcinogens"
        ];
    }

    getCancerSpecificInfo(cancerType) {
        const cancerInfo = {
            "Carcinoma": {
                description: "Cancer that begins in the skin or tissues that line internal organs",
                commonLocations: ["Skin", "Lungs", "Breast", "Prostate", "Colon", "Pancreas"],
                screening: ["Regular physical exams", "Imaging tests", "Biopsies", "Blood tests"],
                prevention: ["Sun protection", "Healthy diet", "Regular exercise", "Avoid tobacco"]
            },
            "Sarcoma": {
                description: "Cancer of connective tissues like bones, muscles, cartilage, and fat",
                commonLocations: ["Bones", "Muscles", "Cartilage", "Fatty tissue", "Blood vessels"],
                screening: ["MRI scans", "CT scans", "Biopsies", "Physical examination"],
                prevention: ["Limited radiation exposure", "Genetic counseling for family history"]
            },
            "Leukemia": {
                description: "Cancer of blood-forming tissues including bone marrow",
                commonLocations: ["Blood", "Bone marrow", "Lymphatic system"],
                screening: ["Blood tests", "Bone marrow biopsy", "Physical examination"],
                prevention: ["Avoid known carcinogens", "Limit radiation exposure", "Healthy lifestyle"]
            },
            "Lymphoma": {
                description: "Cancer that begins in the lymphatic system",
                commonLocations: ["Lymph nodes", "Spleen", "Bone marrow", "Thymus"],
                screening: ["Physical exam", "Blood tests", "Imaging scans", "Biopsy"],
                prevention: ["Maintain healthy immune system", "Avoid infections when possible"]
            },
            "Melanoma": {
                description: "Cancer that develops from pigment-producing cells (melanocytes)",
                commonLocations: ["Skin", "Eyes", "Mucous membranes"],
                screening: ["Skin examination", "Dermatologist visits", "Self-checks"],
                prevention: ["Sun protection", "Avoid tanning beds", "Regular skin checks"]
            },
            "Myeloma": {
                description: "Cancer that forms in plasma cells in bone marrow",
                commonLocations: ["Bone marrow", "Bones"],
                screening: ["Blood tests", "Urine tests", "Bone marrow biopsy"],
                prevention: ["Maintain healthy lifestyle", "Regular check-ups for high-risk individuals"]
            }
        };

        return cancerInfo[cancerType] || {
            description: "General cancer information",
            screening: ["Regular health check-ups", "Discuss family history with doctor"],
            prevention: ["Healthy lifestyle", "Avoid known risk factors", "Regular screenings"]
        };
    }
}

module.exports = new RiskAssessment();